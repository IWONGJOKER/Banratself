# SELFBOTS

# SUPORT
#### Tagall
#### cek sider/cctv
#### tampilkan pp
#### autolike
#### audio/musik
#### translate bahasa
#### Nuke/kickall
#### DLL

V2.1 editor_::
Prankbots
# UPLOADING
V2.1 last update::
23/01/2018
# CONTACT OFFICIAL

<a href="https://line.me/R/ti/p/%40gnh2780p"><img height="36" border="0" alt="Add Friend" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>

# LINE ME

http://line.me/ti/p/~adiputra.95

# TUTORIAL YOUTUBE
#### Command cara install dan loginya ada di deskripsi video
#### Silahkan klik link nya
https://youtu.be/H8cUWlBJG3c
### SUBSCRIBE
https://www.youtube.com/channel/UCycBrqSWEHdk-slnhUmGWiQ


### THANKS TO.

#### Allah swt.
#### Prankbots
#### Black of gamer
Dan kawan"..
